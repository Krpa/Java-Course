/** Automatically generated file. DO NOT MODIFY */
package hr.infinum.fer.ik47861;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}